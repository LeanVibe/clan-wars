# Pet Battle Arena - Development Guide

## 🎮 Prototype Overview

**Pet Battle Arena** is a memory-based card battle game prototype that demonstrates the core mechanics from our "Memory Duel" concept analysis. The game uses a cute pet theme to make it accessible to casual gamers while incorporating strategic depth through memory mechanics.

## 🏗️ Architecture for Agentic Coding

This prototype is specifically designed for rapid iteration with agentic coding tools like Claude Code and Codex CLI:

### Clean Structure
```
pet-battle-arena/
├── index.html          # Main HTML structure
├── style.css          # Complete styling system
├── app.js             # Three.js game logic
└── README.md          # This guide
```

### Key Design Decisions for AI Development

1. **Single File Structure**: All core logic in one `app.js` file for easy AI comprehension
2. **Clear Class Structure**: `PetBattleGame` class with logical method organization
3. **Minimal Dependencies**: Only Three.js from CDN, no build step required
4. **Well-Documented Code**: Extensive comments explaining game state and mechanics
5. **Modular Functions**: Each game action (place card, flip card, combat) is a separate method

## 🎯 Core Mechanics Implemented

### Memory-Based Gameplay
- **Card Placement**: Players place cards face-up on 3x3 grid
- **Auto-Flip**: Cards automatically flip face-down after 3 seconds
- **Memory Challenge**: Players must remember card positions for strategic play
- **Turn-Based**: Alternating player/AI turns with clear feedback

### Visual Features (Three.js)
- **3D Card Flipping**: Smooth rotation animations around X-axis
- **Grid-Based Board**: Clean 3x3 battlefield with hover effects
- **Pet Card Visuals**: Real pet images on 3D card geometries
- **Responsive Design**: Works on mobile and desktop

### Game Balance
- **4 Pet Types**: Cat, Dog, Hamster, Rabbit with balanced attack/health stats
- **Simple Combat**: Adjacent cards battle automatically
- **Health System**: Both players start with 20HP, first to 0 loses
- **AI Opponent**: Basic AI for single-player testing

## 🚀 Iteration Roadmap for Agentic Coding

### Phase 1: Core Polish (Current)
- ✅ Basic 3D card mechanics
- ✅ Memory flip system
- ✅ Simple AI opponent
- ✅ Win/lose conditions

### Phase 2: Enhanced Gameplay
- [ ] **Sound Effects**: Card flip, combat, victory sounds
- [ ] **Particle Effects**: Combat damage, healing sparkles
- [ ] **Card Abilities**: Special pet powers (Rabbit's +1 health)
- [ ] **Improved AI**: Strategic card placement instead of random

### Phase 3: Mobile Optimization
- [ ] **Touch Controls**: Drag-and-drop card placement
- [ ] **Haptic Feedback**: Vibration on card placement/combat
- [ ] **Performance**: Optimize Three.js for mobile GPUs
- [ ] **PWA Features**: Offline play, app-like installation

### Phase 4: Multiplayer (Backend Needed)
- [ ] **Go Backend**: Real-time multiplayer with WebSockets
- [ ] **Room System**: Private matches between friends
- [ ] **Spectator Mode**: Watch other players' matches
- [ ] **Leaderboards**: Ranking system

## 🛠️ Agentic Coding Instructions

### For Claude Code/Codex CLI:

When iterating on this prototype, focus on these patterns:

```javascript
// Adding new pet types - extend this array
this.pets = [
    // Add new pets with balanced stats
    { name: "NewPet", attack: X, health: Y, special: "ability" }
];

// Adding new mechanics - create new methods
addNewMechanic() {
    // Clear method naming
    // Update game state
    // Trigger UI updates
}

// Visual improvements - modify these methods
createCard(), flipCard(), animateAction()
```

### Key Files to Modify:

1. **app.js**: All game logic and Three.js rendering
2. **style.css**: UI styling and responsive design  
3. **index.html**: HTML structure and game screens

### Testing Approach:
1. Open `index.html` in browser (no build step needed)
2. Test on mobile device for touch responsiveness
3. Check memory mechanics by playing several turns
4. Verify win/lose conditions work correctly

## 🎨 Asset Integration

### Pet Card Images
The prototype uses generated pet images from S3 URLs. For production:
- Replace with local image files
- Add loading states for images
- Create consistent aspect ratios (recommended: 256x256px)

### Additional Assets Needed
- **Card back design**: Generic pattern for face-down cards
- **Sound effects**: Flip, combat, victory/defeat sounds  
- **UI icons**: Settings, restart, help buttons
- **Background**: Subtle pattern or gradient

## 🎯 What Makes This Prototype Effective

### For Casual Gamers:
- **Cute Pet Theme**: Universal appeal, non-threatening
- **Simple Rules**: "Place cards, remember positions"
- **Quick Sessions**: 2-3 minute matches
- **Clear Visual Feedback**: Immediate understanding of game state

### For Strategic Depth:
- **Memory Skill**: Core differentiator from other card games
- **Positioning Strategy**: Grid placement matters for combat
- **Resource Management**: Limited hand size creates tough choices
- **Prediction Game**: Anticipating opponent's forgotten cards

### For Developers:
- **Clean Codebase**: Easy to understand and modify
- **Three.js Integration**: Professional 3D graphics
- **Mobile-First**: Touch-optimized from the start
- **Extensible Design**: Easy to add new features

## 🔄 Next Steps for Development

1. **Playtest the Current Prototype**: Identify friction points
2. **Polish Core Mechanics**: Smooth all animations and feedback
3. **Add Audio**: Sound makes mobile games feel complete
4. **Optimize Performance**: Ensure 60fps on mobile devices
5. **Plan Backend**: Design multiplayer architecture with Go

This prototype successfully demonstrates that the Memory Duel concept can work as an engaging casual mobile game while maintaining strategic depth through memory mechanics.